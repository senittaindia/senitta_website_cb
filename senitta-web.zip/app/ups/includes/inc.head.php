<?
	$access_key = 'FCD7C8F94CB5EF46';
	$user_name = 'nyblueprint';
	$password = 'delfia11';
?>